package cz.martykan.forecastie.tasks;

public enum TaskResult { SUCCESS, HTTP_ERROR, IO_EXCEPTION, TOO_MANY_REQUESTS, INVALID_API_KEY; }
