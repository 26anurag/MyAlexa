Forecastie
안드로이드를 위한 간단한 오픈 소스 날씨 앱. 공개 API를 통해 OpenWeatherMap 에서 데이터를 수집합니다.
특징

    심플한 디자인
    자세한 날씨 예측
    여러 유닛
    전 세계의 모든 도시에서 작동
    오프라인에서의 기능
    Contribution
    아이디어 나 문제가 있으면 언제든지 문의 주세요. 모든 Contribution을 환영합니다.
    특허
    이 응용 프로그램은 자유 소프트웨어입니다: 당신은 당신의 의지에 따라 공유를 연구하고 향상시킬 수 있습니다. 특히, 자유 소프트웨어 재단 (Free Software Foundation)이 발행 한 GNU General Public License 의 조건에 따라 라이센스 버전 3 또는 이후 버전에 따라 재배포 및/또는 수정할 수 있습니다.
    날씨 데이터는 Creative Commons 라이센스에 따라 OpenWeatherMap 에서 제공합니다.
    아이콘은 날씨 아이콘, 루카스 비숍 과 에릭 꽃 에 의해, SIL OFL 1.1 라이센스 이하.
